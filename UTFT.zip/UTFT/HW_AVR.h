// *** Hardwarespecific functions ***
void UTFT::LCD_Writ_Bus(char VH,char VL, byte mode)
{   
	unsigned char i,temp,data;
	data=VL;
	for(i=8;i<=9;i++)
		{
			temp=(data&0x01);
			if(temp)
			digitalWrite(i,HIGH);
			else
			digitalWrite(i,LOW);
			data=data>>1;
		}	
	for(i=2;i<=7;i++)
		{
			temp=(data&0x01);
			if(temp)
			digitalWrite(i,HIGH);
			else
			digitalWrite(i,LOW);
			data=data>>1;
		}

	pulse_low(P_WR, B_WR);
	
}

void UTFT::_set_direction_registers(byte mode)
{
for(int p=2;p<10;p++)
 	 {
	    pinMode(p,OUTPUT);
	  }
/*

	pinMode(2,OUTPUT);
	pinMode(3,OUTPUT);
	pinMode(4,OUTPUT);
	pinMode(5,OUTPUT);
	pinMode(6,OUTPUT);
	pinMode(7,OUTPUT);
	pinMode(8,OUTPUT);
	pinMode(9,OUTPUT);
*/
}
